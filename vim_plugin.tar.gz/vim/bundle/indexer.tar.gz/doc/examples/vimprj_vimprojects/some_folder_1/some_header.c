#include "main.h"

int my_func_1()
{
   my_global_long++;
}

int my_func_2()
{
   my_global_int++;
}


