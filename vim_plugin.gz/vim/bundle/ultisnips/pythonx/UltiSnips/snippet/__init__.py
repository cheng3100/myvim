"""Code related to snippets."""
